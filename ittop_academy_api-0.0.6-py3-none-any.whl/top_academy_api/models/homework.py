from typing import List, Optional, Iterator

from pydantic import BaseModel, RootModel


class HomeworkCounter(BaseModel):
    counter_type: int
    counter: int

class HomeworkCounters(RootModel[List[HomeworkCounter]]):
    root: List[HomeworkCounter]

    def __iter__(self) -> Iterator[HomeworkCounter]:
        return iter(self.root)

    def __getitem__(self, index) -> HomeworkCounter:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)

class HomeworkStudentInfo(BaseModel):
    id: int
    filename: Optional[str]
    file_path: Optional[str]
    tmp_file: Optional[str]
    mark: Optional[int]
    creation_time: Optional[str]
    stud_answer: Optional[str]
    auto_mark: bool


class HomeworkItem(BaseModel):
    id: int
    id_spec: int
    id_teach: int
    id_group: int
    fio_teach: str
    theme: str
    completion_time: str
    creation_time: str
    overdue_time: Optional[str]
    filename: Optional[str]
    file_path: Optional[str]
    comment: Optional[str]
    name_spec: str
    status: int
    common_status: Optional[int]
    homework_stud: Optional[HomeworkStudentInfo]
    homework_comment: Optional[str]
    cover_image: Optional[str]


class HomeworkList(RootModel[List[HomeworkItem]]):
    root: List[HomeworkItem]

    def __iter__(self) -> Iterator[HomeworkItem]:
        return iter(self.root)

    def __getitem__(self, index) -> HomeworkItem:
        return self.root[index]

    def __len__(self) -> int:
        return len(self.root)

    def __str__(self) -> str:
        return str(self.root)

class HomeworkUploadResponse(BaseModel):
    id: int
    filename: Optional[str]
    file_path: Optional[str]
    tmp_file: Optional[str]
    mark: Optional[int]
    creation_time: str
    stud_answer: Optional[str]
    auto_mark: bool


class HomeworkEvaluationResponse(BaseModel):
    id: int
    id_dom_zad: int
    id_stud: int
    mark: int
    comment: str
    tags: List[str]
