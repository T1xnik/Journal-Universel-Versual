"""
Дополнительные эндпоинты из journal SPA + Postman ITTOPAcademy API:
Library, Payment, Profile, Progress, Portfolio, Settings, Contacts, Reviews,
Feedback, News, Signal, Story, Public, Files.
Ответы возвращаются как dict/list (Any); см. docs/API_ENDPOINTS.md.
"""

from typing import Any, Optional


class LibraryEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_opened_interview(self) -> Any:
        """GET /library/quiz/opened-interview."""
        return await self._client._request("GET", "/library/quiz/opened-interview")

    async def list_(
        self,
        material_type: int = 7,
        recommended_type: int = 0,
    ) -> Any:
        """GET /library/operations/list."""
        return await self._client._request(
            "GET",
            "/library/operations/list",
            params={"material_type": material_type, "recommended_type": recommended_type},
        )

    async def list_all(self, **params: Any) -> Any:
        """GET /library/operations/list-all."""
        return await self._client._request("GET", "/library/operations/list-all", params=params or None)

    async def check_url(self, payload: dict[str, Any]) -> Any:
        """POST /library/operations/check-url."""
        return await self._client._request("POST", "/library/operations/check-url", json_=payload)

    async def quizzes_academic_debt(self, **params: Any) -> Any:
        """GET /library/operations/quizzes-academic-debt."""
        return await self._client._request(
            "GET", "/library/operations/quizzes-academic-debt", params=params or None
        )

    async def set_use_material(self, payload: dict[str, Any]) -> Any:
        """POST /library/operations/set-use-material."""
        return await self._client._request(
            "POST", "/library/operations/set-use-material", json_=payload
        )

    async def quiz_run(self, payload: dict[str, Any]) -> Any:
        """POST /library/quiz/run."""
        return await self._client._request("POST", "/library/quiz/run", json_=payload)

    async def quiz_finish(self, payload: dict[str, Any]) -> Any:
        """POST /library/quiz/finish."""
        return await self._client._request("POST", "/library/quiz/finish", json_=payload)

    async def quiz_delay_interview(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /library/quiz/delay-interview."""
        return await self._client._request(
            "POST", "/library/quiz/delay-interview", json_=payload or {}
        )

    async def quiz_get_time_between_retries(self, **params: Any) -> Any:
        """GET /library/quiz/get-time-between-retries."""
        return await self._client._request(
            "GET", "/library/quiz/get-time-between-retries", params=params or None
        )


class PaymentEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def check_epay_link(self) -> Any:
        """HEAD /payment/epay/link."""
        try:
            r = await self._client._client.request("HEAD", "/payment/epay/link")
            r.raise_for_status()
            return {"ok": True, "status": r.status_code}
        except Exception:
            return {"ok": False}

    async def create_epay_link(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /payment/epay/link."""
        return await self._client._request("POST", "/payment/epay/link", json_=payload or {})

    async def get_schedule(self) -> Any:
        """GET /payment/operations/schedule."""
        return await self._client._request("GET", "/payment/operations/schedule")

    async def get_index(self) -> Any:
        """GET /payment/operations/index."""
        return await self._client._request("GET", "/payment/operations/index")

    async def get_history(self) -> Any:
        """GET /payment/operations/history."""
        return await self._client._request("GET", "/payment/operations/history")

    async def check_cancellation(self) -> Any:
        """GET /payment/operations/check-cancellation."""
        return await self._client._request("GET", "/payment/operations/check-cancellation")

    async def get_contract(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /payment/operations/contract."""
        return await self._client._request(
            "POST", "/payment/operations/contract", json_=payload or {}
        )

    async def create_link(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /payment/operations/link."""
        return await self._client._request("POST", "/payment/operations/link", json_=payload or {})

    async def download_requisites(self, **params: Any) -> Any:
        """GET /payment/operations/download-requisites (SPA also POST)."""
        return await self._client._request(
            "GET", "/payment/operations/download-requisites", params=params or None
        )


class ProfileEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_student_achievements(self) -> Any:
        """GET /profile/statistic/student-achievements."""
        return await self._client._request("GET", "/profile/statistic/student-achievements")

    async def get_settings(self) -> Any:
        """GET /profile/operations/settings."""
        return await self._client._request("GET", "/profile/operations/settings")

    async def update_settings(self, payload: dict[str, Any]) -> Any:
        """POST /profile/operations/settings."""
        return await self._client._request("POST", "/profile/operations/settings", json_=payload)

    async def change_password(self, payload: dict[str, Any]) -> Any:
        """POST /profile/operations/change-password."""
        return await self._client._request(
            "POST", "/profile/operations/change-password", json_=payload
        )

    async def change_personal_data(self, payload: dict[str, Any]) -> Any:
        """POST /profile/operations/change-personal-data."""
        return await self._client._request(
            "POST", "/profile/operations/change-personal-data", json_=payload
        )


class ProgressEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_student_visits(self) -> Any:
        """GET /progress/operations/student-visits."""
        return await self._client._request("GET", "/progress/operations/student-visits")

    async def get_student_exams(self) -> Any:
        """GET /progress/operations/student-exams."""
        return await self._client._request("GET", "/progress/operations/student-exams")

    async def get_plan_url(self, **params: Any) -> Any:
        """GET /progress/operations/plan-url."""
        return await self._client._request(
            "GET", "/progress/operations/plan-url", params=params or None
        )

    async def get_school_quarterly_grades(self, **params: Any) -> Any:
        """GET /progress/operations/school-quarterly-grades."""
        return await self._client._request(
            "GET", "/progress/operations/school-quarterly-grades", params=params or None
        )

    async def upload_student_exams_file(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /progress/operations/student-exams-file."""
        return await self._client._request(
            "POST", "/progress/operations/student-exams-file", json_=payload or {}
        )


class PortfolioEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def list_(self) -> Any:
        """GET /portfolio/operations/list."""
        return await self._client._request("GET", "/portfolio/operations/list")

    async def get_design_teachers(self) -> Any:
        """GET /portfolio/operations/design-teachers."""
        return await self._client._request("GET", "/portfolio/operations/design-teachers")

    async def get_design_specs(self, id_spec: Optional[int] = None) -> Any:
        """GET /portfolio/operations/design-specs."""
        params = {"id": id_spec} if id_spec is not None else None
        return await self._client._request(
            "GET", "/portfolio/operations/design-specs", params=params
        )

    async def get_history(self, **params: Any) -> Any:
        """GET /portfolio/operations/history."""
        return await self._client._request(
            "GET", "/portfolio/operations/history", params=params or None
        )

    async def create(self, payload: dict[str, Any]) -> Any:
        """POST /portfolio/operations/create."""
        return await self._client._request("POST", "/portfolio/operations/create", json_=payload)

    async def delete(self, payload: dict[str, Any]) -> Any:
        """POST /portfolio/operations/delete."""
        return await self._client._request("POST", "/portfolio/operations/delete", json_=payload)


class SettingsEndpoints:
    """Доп. настройки (user.get_info = GET /settings/user-info уже есть в UserEndpoints)."""

    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_history_specs(self) -> Any:
        """GET /settings/history-specs."""
        return await self._client._request("GET", "/settings/history-specs")

    async def get_group_specs(self) -> Any:
        """GET /settings/group-specs."""
        return await self._client._request("GET", "/settings/group-specs")

    async def get_public_forms(self) -> Any:
        """GET /settings/public-forms."""
        return await self._client._request("GET", "/settings/public-forms")

    async def get_public_specs(self) -> Any:
        """GET /settings/public-specs."""
        return await self._client._request("GET", "/settings/public-specs")

    async def change_current_group(self, payload: dict[str, Any]) -> Any:
        """POST /settings/change-current-group."""
        return await self._client._request(
            "POST", "/settings/change-current-group", json_=payload
        )

    async def get_admin_groups(self, **params: Any) -> Any:
        """GET /settings/admin-groups."""
        return await self._client._request(
            "GET", "/settings/admin-groups", params=params or None
        )

    async def get_admin_group_students(self, **params: Any) -> Any:
        """GET /settings/admin-group-students."""
        return await self._client._request(
            "GET", "/settings/admin-group-students", params=params or None
        )


class ContactsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def check_mailing_confirmation(self) -> Any:
        """GET /contacts/mailing/check-confirmation."""
        return await self._client._request("GET", "/contacts/mailing/check-confirmation")

    async def get_contacts(self) -> Any:
        """GET /contacts/operations/index."""
        return await self._client._request("GET", "/contacts/operations/index")

    async def check_unsubscription_key(self, **params: Any) -> Any:
        """GET /contacts/mailing/check-unsubscription-key."""
        return await self._client._request(
            "GET", "/contacts/mailing/check-unsubscription-key", params=params or None
        )

    async def confirm_mailing(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /contacts/mailing/confirm."""
        return await self._client._request(
            "POST", "/contacts/mailing/confirm", json_=payload or {}
        )

    async def delay_confirmation(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /contacts/mailing/delay-confirmation."""
        return await self._client._request(
            "POST", "/contacts/mailing/delay-confirmation", json_=payload or {}
        )

    async def emails_list(self, **params: Any) -> Any:
        """GET /contacts/mailing/emails-list."""
        return await self._client._request(
            "GET", "/contacts/mailing/emails-list", params=params or None
        )

    async def send_confirmation(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /contacts/mailing/send-confirmation."""
        return await self._client._request(
            "POST", "/contacts/mailing/send-confirmation", json_=payload or {}
        )

    async def unsubscribe(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /contacts/mailing/unsubscribe."""
        return await self._client._request(
            "POST", "/contacts/mailing/unsubscribe", json_=payload or {}
        )

    async def send_ceo(self, payload: dict[str, Any]) -> Any:
        """POST /contacts/operations/send-ceo."""
        return await self._client._request("POST", "/contacts/operations/send-ceo", json_=payload)

    async def send_teach(self, payload: dict[str, Any]) -> Any:
        """POST /contacts/operations/send-teach."""
        return await self._client._request("POST", "/contacts/operations/send-teach", json_=payload)

    async def sms_send_code(self, payload: dict[str, Any]) -> Any:
        """POST /contacts/sms/send-code."""
        return await self._client._request("POST", "/contacts/sms/send-code", json_=payload)

    async def sms_verified_phone(self, payload: dict[str, Any]) -> Any:
        """POST /contacts/sms/verified-phone."""
        return await self._client._request("POST", "/contacts/sms/verified-phone", json_=payload)


class ReviewsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def list_(self) -> Any:
        """GET /reviews/index/list."""
        return await self._client._request("GET", "/reviews/index/list")

    async def get_instruction(self) -> Any:
        """GET /reviews/index/instruction."""
        return await self._client._request("GET", "/reviews/index/instruction")


class FeedbackEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_evaluate_lesson_list(self) -> Any:
        """GET /feedback/students/evaluate-lesson-list."""
        return await self._client._request("GET", "/feedback/students/evaluate-lesson-list")

    async def get_social_reviews(self) -> Any:
        """GET /feedback/social-review/get-review-list."""
        return await self._client._request("GET", "/feedback/social-review/get-review-list")

    async def screen_review(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /feedback/social-review/screen-review."""
        return await self._client._request(
            "POST", "/feedback/social-review/screen-review", json_=payload or {}
        )

    async def evaluate_lesson(self, payload: dict[str, Any]) -> Any:
        """POST /feedback/students/evaluate-lesson."""
        return await self._client._request(
            "POST", "/feedback/students/evaluate-lesson", json_=payload
        )

    async def evaluate_academy_day(self, payload: dict[str, Any]) -> Any:
        """POST /feedback/students/evaluate-academy-day."""
        return await self._client._request(
            "POST", "/feedback/students/evaluate-academy-day", json_=payload
        )

    async def comment_academy_day(self, payload: dict[str, Any]) -> Any:
        """POST /feedback/students/comment-academy-day."""
        return await self._client._request(
            "POST", "/feedback/students/comment-academy-day", json_=payload
        )


class NewsEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_latest(self) -> Any:
        """GET /news/operations/latest-news."""
        return await self._client._request("GET", "/news/operations/latest-news")

    async def count_unread(self) -> Any:
        """GET /news/operations/count-unread."""
        return await self._client._request("GET", "/news/operations/count-unread")

    async def detail(self, news_id: int | str, **params: Any) -> Any:
        """GET /news/operations/detail-news."""
        q = {"id": news_id, **params}
        return await self._client._request("GET", "/news/operations/detail-news", params=q)

    async def set_view(self, payload: dict[str, Any]) -> Any:
        """POST /news/operations/set-view."""
        return await self._client._request("POST", "/news/operations/set-view", json_=payload)


class SignalEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def list_(self) -> Any:
        """GET /signal/operations/signals-list."""
        return await self._client._request("GET", "/signal/operations/signals-list")

    async def count_unread(self) -> Any:
        """GET /signal/operations/count-unread."""
        return await self._client._request("GET", "/signal/operations/count-unread")

    async def create(self, payload: dict[str, Any]) -> Any:
        """POST /signal/operations/create."""
        return await self._client._request("POST", "/signal/operations/create", json_=payload)

    async def update(self, payload: dict[str, Any]) -> Any:
        """POST /signal/operations/update."""
        return await self._client._request("POST", "/signal/operations/update", json_=payload)

    async def delete(self, payload: dict[str, Any]) -> Any:
        """POST /signal/operations/delete."""
        return await self._client._request("POST", "/signal/operations/delete", json_=payload)

    async def approve(self, payload: dict[str, Any]) -> Any:
        """POST /signal/operations/approve."""
        return await self._client._request("POST", "/signal/operations/approve", json_=payload)

    async def set_to_work(self, payload: dict[str, Any]) -> Any:
        """POST /signal/operations/set-to-work."""
        return await self._client._request("POST", "/signal/operations/set-to-work", json_=payload)

    async def set_view(self, payload: dict[str, Any]) -> Any:
        """POST /signal/operations/set-view."""
        return await self._client._request("POST", "/signal/operations/set-view", json_=payload)

    async def get_reference_data(self, **params: Any) -> Any:
        """GET /signal/operations/get-reference-data."""
        return await self._client._request(
            "GET", "/signal/operations/get-reference-data", params=params or None
        )

    async def get_reference_status(self, **params: Any) -> Any:
        """GET /signal/operations/get-reference-status."""
        return await self._client._request(
            "GET", "/signal/operations/get-reference-status", params=params or None
        )

    async def problems_list(self, **params: Any) -> Any:
        """GET /signal/operations/problems-list."""
        return await self._client._request(
            "GET", "/signal/operations/problems-list", params=params or None
        )

    async def signals_comments(self, **params: Any) -> Any:
        """GET /signal/operations/signals-comments."""
        return await self._client._request(
            "GET", "/signal/operations/signals-comments", params=params or None
        )


class StoryEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_stories(self) -> Any:
        """GET /story/operations/get-stories."""
        return await self._client._request("GET", "/story/operations/get-stories")

    async def get_login_page_stories(self) -> Any:
        """GET /story/operations/get-login-page-stories."""
        return await self._client._request("GET", "/story/operations/get-login-page-stories")

    async def send_lead(self, payload: dict[str, Any]) -> Any:
        """POST /story/operations/send-lead."""
        return await self._client._request("POST", "/story/operations/send-lead", json_=payload)


class PublicEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_languages(self) -> Any:
        """GET /public/languages."""
        return await self._client._request("GET", "/public/languages")

    async def get_cities(self, **params: Any) -> Any:
        """GET /public/cities."""
        return await self._client._request("GET", "/public/cities", params=params or None)

    async def get_tags(self, **params: Any) -> Any:
        """GET /public/tags."""
        return await self._client._request("GET", "/public/tags", params=params or None)

    async def get_translations(self, **params: Any) -> Any:
        """GET /public/translations."""
        return await self._client._request("GET", "/public/translations", params=params or None)


class FilesEndpoints:
    """
    Файлы. В коллекции Postman: Download Homework File ведёт на storage.yandexcloud.net,
    Get File — на fs.top-academy.ru. Ниже — вызовы к msapi; при необходимости URL для
    скачивания берётся из ответа API (например, file_path в homework).
    """

    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_file_url(self, file_id: str) -> Any:
        """GET /files/operations/get — метаданные/URL файла на msapi (если доступен)."""
        return await self._client._request("GET", "/files/operations/get", params={"id": file_id})
