from typing import Any, Optional

from ..models.schedule import ScheduleDay, ScheduleMonth


class ScheduleEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def get_schedule_month(self, date: str) -> ScheduleMonth:
        data = await self._client._request(
            "GET", "/schedule/operations/get-month", params={"date_filter": date}
        )
        return ScheduleMonth.model_validate(data)

    async def get_schedule_day(self, date: str) -> ScheduleDay:
        data = await self._client._request(
            "GET", "/schedule/operations/get-by-date", params={"date_filter": date}
        )
        return ScheduleDay.model_validate(data)

    async def get_by_date_range(
        self,
        date_start: str,
        date_end: str,
        *,
        extra_params: Optional[dict[str, Any]] = None,
    ) -> Any:
        """GET /schedule/operations/get-by-date-range."""
        params = {"date_start": date_start, "date_end": date_end}
        if extra_params:
            params.update(extra_params)
        return await self._client._request(
            "GET", "/schedule/operations/get-by-date-range", params=params
        )

    async def get_month_events(self, date: str) -> Any:
        """GET /schedule/operations/month-events?date_filter=..."""
        return await self._client._request(
            "GET",
            "/schedule/operations/month-events",
            params={"date_filter": date},
        )
