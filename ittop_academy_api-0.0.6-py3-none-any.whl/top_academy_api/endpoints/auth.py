from typing import Any, Optional

from ..exceptions import TopAcademyAuthError
from ..models.auth import AuthLogin


class AuthEndpoints:
    def __init__(self, client: "TopAcademyClient"):
        self._client = client

    async def login(self, app_key: str, username: str, password: str) -> AuthLogin:
        payload = {
            "application_key": app_key,
            "id_city": None,
            "username": username,
            "password": password,
        }

        try:
            data = await self._client._request("POST", "/auth/login", json_=payload)
        except Exception as e:
            raise TopAcademyAuthError("") from e

        model: AuthLogin = AuthLogin.model_validate(data)
        self._client._client.headers.update({"Authorization": f"Bearer {model.access_token}"})
        return model

    async def logout(self) -> None:
        await self._client._request("POST", "/auth/logout")

    async def refresh(self, refresh_token: str) -> AuthLogin:
        """
        POST /auth/refresh (SPA also probes HEAD).
        Обновить access_token по refresh_token.
        """
        data = await self._client._request(
            "POST",
            "/auth/refresh",
            json_={"refresh_token": refresh_token},
        )
        model = AuthLogin.model_validate(data)
        self._client._client.headers.update({"Authorization": f"Bearer {model.access_token}"})
        return model

    async def file_token(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /auth/file-token — токен для скачивания файлов (FS)."""
        return await self._client._request("POST", "/auth/file-token", json_=payload or {})

    async def handoff(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /auth/handoff."""
        return await self._client._request("POST", "/auth/handoff", json_=payload or {})

    async def reset_password(self, payload: dict[str, Any]) -> Any:
        """POST /auth/reset-password."""
        return await self._client._request("POST", "/auth/reset-password", json_=payload)

    async def login_admin(self, payload: dict[str, Any]) -> Any:
        """POST /auth/login-admin."""
        return await self._client._request("POST", "/auth/login-admin", json_=payload)

    async def login_as_child(self, payload: dict[str, Any]) -> Any:
        """POST /auth/login-as-child."""
        return await self._client._request("POST", "/auth/login-as-child", json_=payload)

    async def login_as_student(self, payload: dict[str, Any]) -> Any:
        """POST /auth/login-as-student."""
        return await self._client._request("POST", "/auth/login-as-student", json_=payload)

    async def login_market_admin(self, payload: dict[str, Any]) -> Any:
        """POST /auth/login-market-admin."""
        return await self._client._request("POST", "/auth/login-market-admin", json_=payload)

    async def logout_as_student(self, payload: Optional[dict[str, Any]] = None) -> Any:
        """POST /auth/logout-as-student."""
        return await self._client._request(
            "POST", "/auth/logout-as-student", json_=payload or {}
        )
